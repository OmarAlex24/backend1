public class ArbolFrutal extends Arbol {
    public ArbolFrutal() {
        this.setTipoDeArbol("Frutal");
        this.setColor("Rojo");
        this.setAlto(500);
        this.setAncho(300);
    }
}
