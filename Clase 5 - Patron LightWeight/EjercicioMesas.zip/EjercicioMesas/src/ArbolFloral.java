public class ArbolFloral extends Arbol{
    public ArbolFloral() {
        this.setTipoDeArbol("Floral");
        this.setColor("Celeste");
        this.setAlto(100);
        this.setAncho(200);
    }
}
