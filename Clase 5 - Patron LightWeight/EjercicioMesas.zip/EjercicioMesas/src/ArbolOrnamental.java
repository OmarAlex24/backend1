public class ArbolOrnamental extends Arbol{
    public ArbolOrnamental() {
        this.setTipoDeArbol("Ornamental");
        this.setColor("Verde");
        this.setAlto(200);
        this.setAncho(400);
    }
}
